from flask import Flask, request, jsonify
import bcrypt
import sqlite3

app = Flask(__name__)

# Conecta ao banco de dados SQLite (cria o arquivo banco_prof.db se não existir)
conn = sqlite3.connect('banco_prof.db', check_same_thread=False)
c = conn.cursor()

# Cria a tabela de usuários se não existir
c.execute('''CREATE TABLE IF NOT EXISTS users
             (username TEXT PRIMARY KEY, password TEXT)''')
conn.commit()

# Função para cadastrar um novo usuário
@app.route('/cadastrar', methods=['POST'])
def cadastrar_usuario():
    data = request.json
    usuario = data['email']
    senha = data['senha']

    # Verifica se o usuário já existe
    c.execute("SELECT 1 FROM users WHERE username=?", (usuario,))
    if c.fetchone():
        return jsonify({"message": "Usuário já existe!"}), 400

    # Criptografa a senha
    senha_criptografada = bcrypt.hashpw(senha.encode('utf-8'), bcrypt.gensalt())

    # Insere o novo usuário no banco de dados
    c.execute("INSERT INTO users (username, password) VALUES (?, ?)",
              (usuario, senha_criptografada.decode('utf-8')))
    conn.commit()
    return jsonify({"message": "Usuário cadastrado com sucesso!"}), 201

# Função para fazer login
@app.route('/login', methods=['POST'])
def login_usuario():
    data = request.json
    usuario = data['email']
    senha = data['senha']

    # Verifica se o usuário existe no banco de dados
    c.execute("SELECT password FROM users WHERE username=?", (usuario,))
    row = c.fetchone()
    if row and bcrypt.checkpw(senha.encode('utf-8'), row[0].encode('utf-8')):
        return jsonify({"message": "Login bem-sucedido!"}), 200
    return jsonify({"message": "Usuário ou senha incorretos!"}), 401

# Executa a aplicação
if __name__ == '__main__':
    app.run(debug=True)