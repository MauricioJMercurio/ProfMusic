import sqlite3

banco = sqlite3.connect('banco_prof.db')
cursor = banco.cursor()

#cursor.execute("CREATE TABLE IF NOT EXISTS pessoas (nome text, senha integer, email text)")
cursor.execute("INSERT INTO pessoas VALUES('Mauricio', 1234, 'mauricio_123@gmail.com')")

banco.commit()
banco.close()
